Use the following commands to configure the environment:
conda create -n RecGFI python=3.8
conda activate RecGFI
python -m pip install -r requirements-lock.txt

Then run RecGFI/Main.py and you can get five csv files in RecGFI/models, which are the results for RQ1 in our paper. The results for RQ2 is shown in RecGFI/data/Statistics.png. Then execute the command jupyter notebook and run real_world_evaluation_results.ipynb in the website to get the results for RQ3.