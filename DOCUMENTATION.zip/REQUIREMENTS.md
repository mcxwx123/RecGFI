## Hardware environment 
We conduct development and execute all our experiments on a Ubuntu 20.04 server with two Intel Xeon Gold CPUs, 320GB memory, and 36TB RAID 5 Storage. We have also vetted this replication package in a Ubuntu 20.04 VirtualBox VM with 1 CPU Core, 8GB Memory and 100GB storage.

## Software environment
The software requirements for this replication package has already been described in the README and the requirements.txt file in this folder. We recommend to either exactly follow the installation commands to configure an Anaconda environment as follows, or to directly use the VM Image. Although we have only tested our replication package on Ubuntu 20.04, it should also work in other common Linux distributions because we do not rely on any OS specific features.

```shell script
conda create -n RecGFI python=3.8
conda activate RecGFI
python -m pip install -r requirements-lock.txt
```

The VM image for this artifact is available at .
