We intend to claim the Artifacts Available badge and the Artifacts Evaluated - Reusable badge for our replication package.

Reasons:
We provide three ways to download our artifact including Github repository, VM image and Zenodo archive. We introduce the background, requirment environment and steps of the artifact to reproduce the results of our paper. Therefore, we believe our artifact is available and reusable.
