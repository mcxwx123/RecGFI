We intend to claim the Artifacts Available badge and the Artifacts Evaluated - Reusable badge for our replication package.

Reasons:
We provide persistent ways to download our artifact from Zenodo and GitHub repository. We also provide a VM image to ensure reprodicibility. We introduce the background, requirment environment and steps of the artifact to reproduce the results of our paper. Therefore, we believe our artifact is available and reusable.
